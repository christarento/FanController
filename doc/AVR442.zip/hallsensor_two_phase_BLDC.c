// This file has been prepared for Doxygen automatic documentation generation.
/*! \file ********************************************************************
*
* Atmel Corporation
*
* - File              : hallsensor_two_phase_BLDC.c
* - Compiler          : IAR EWAAVR 3.20c
*
* - Support mail      : avr@atmel.com
*
* - Supported devices : Devices with 8 bit timer with 2 PWM outputs and 2 ADC channels can be used.
*                       The example is written for ATtiny13
*
* - AppNote           : AVR442 - PC fan control using tiny13
*
* - Description       : Control of two-phase Brushless DC motor with Hall sensor.
*                       Implementation made for a standard PC fan.
*
* $Revision: 1.2 $
* Original Author: Robert Staven, Atmel Corp.
* $Author: rstaven $, Atmel Corp.
* $Date: Friday, June 24, 2005 08:17:02 UTC $
*****************************************************************************/

#include <iotiny13.h>
#include <inavr.h>
#include "hallsensor_two_phase_BLDC.h"

//! Dutycycle of PWM signal used to power motor
unsigned char coilDuty = 0xFF;
//! Count time since last Hall sensor signal
unsigned int stallTime = 0;
//! Used to make delay for stall timeout
unsigned long delayCounter = 0;

/*! \brief Flags for motor status
 */
struct GLOBAL_FLAGS {
  //! True when motor stalled
  unsigned char stall:1;
  //! True when starting motor
  unsigned char starting:1;
  //! True on alarm
  unsigned char alarm:1;
  unsigned char dummy:5;
} gFlags = {FALSE, TRUE, FALSE, 0};

//! Look up table used for PWM input values
__flash unsigned char LUT_for_PWM[] = {20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 22, 24, 26,
                                       28, 30, 32, 34, 36, 38, 40, 42, 44, 46, 48, 50, 52, 54, 56, 58,
                                       60, 62, 64, 66, 68, 70, 72, 74, 76, 78, 80, 82, 84, 86, 88, 90,
                                       92, 94, 95, 98,101,104,107,110,113,116,119,122,125,128,131,135};

//! Look up table used for thermistor input values
__flash unsigned char LUT_for_Thermistor[] = {255,255,255,248,241,234,227,220,213,206,199,192,185,178,171,163,
                                              156,149,142,135,128,121,113,106, 99, 92, 85, 78, 71, 64, 55, 48,
                                               41, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35};

/*! \brief Fan controller demo
 *
 * Starts up fan, Read temprature and PWMin and sets PWMduty.
 * Waits and restarts when detecting stall
 */
void main( void )
{
  //! Thermistor AD value
  unsigned int t_ad;
  //! Thermistor LUT index
  unsigned char t_idx;
  //! PWM input AD value
  unsigned int pwm_ad;
  //! Temporary coilDuty value
  unsigned int duty;

  // Initialize the controller
  init();

  // Start up the fan
  startFan();

  while(1)
  {

    // Read thermistor
    t_ad = ADC_read(1);
    // LUT only covers AD values from 256 to 639, so keep index within 0-47
    if(t_ad < 256)
      t_idx = 0;
    else if(t_ad >= 640)
      t_idx = 47;
    else
      t_idx = (t_ad/8)-32;

    // Read PWM input
    pwm_ad = ADC_read(2);

    // Calculate power to motor
    duty = (LUT_for_PWM[pwm_ad/16] * LUT_for_Thermistor[t_idx]) >> 7;
    // Limit coil duty to 255
    if(duty > 255)
      duty = 255;

    // Do not update coilDuty when starting
    if(gFlags.starting == FALSE)
      coilDuty = duty;

    // Stalled rotor, raise alarm, power off, wait and restart
    if(gFlags.stall == TRUE){
      gFlags.alarm = TRUE;
      // Set alarm output pin HIGH
      PORTB |= (1 << PB5);
      // Turn off power
      coilDuty = 0;
      // Reset stalltimeout counter
      delayCounter = 0;
      // Wait until delay finished
      while(delayCounter <= STALLTIMEOUT);
      gFlags.alarm = FALSE;
      PORTB &= ~(1 << PB5);
      stallTime = 0;
      gFlags.stall = FALSE;
      // Start up the fan again
      startFan();
    }

  } // end while(1)
}


/*! \brief Hall signal change ISR
 *
 * Activate coils and resets stall timer
 */
#pragma vector = PCINT0_vect
__interrupt void pin_change(void)
{
  // Got Hall sensor signal, so rotor is moving and starting is finished
  gFlags.starting = FALSE;
  // Activate the correct coil
  coilActivate();

  // Reset time since last Hall sensor change
  stallTime = 0;
}


/*! \brief Timer 0 overflow ISR
 *
 * Timer0 overflow interrupt - 18750Hz
 * Sets coilduty, increases stalltime and delaycounter
 */
#pragma vector = TIM0_OVF_vect
__interrupt void TIM0_OVF(void)
{
  OCR0A = coilDuty;                         // compare match for OC1A
  OCR0B = coilDuty;                         // compare match for OC1B

  // Increment as long as not at stall limit, othervise raise stall flag
  if(stallTime < STALL_LIM)
    stallTime++;
  else
    gFlags.stall = TRUE;

  // Increment
  if(delayCounter < 0xFFFFFFFF)
    delayCounter++;

  return;
}


/*! \brief Initialisation
 */
#pragma inline=forced
void init(void)
{
  // Set clock prescaler: 0 gives full 4.8 MHz from internal oscillator.
  CLKPR = (1 << CLKPCE);
  CLKPR = 0;

  // Set outputs. OC1A and OC1B control fan coils, PB5 alarm output
  DDRB = (1 << PB5) | (1 << PB1) | (1 << PB0);

  Init_TC0();
  Init_ADC();

  // Pin change int on Hall toggle
  PCMSK = IO_HALL;
  GIMSK |= (1 << PCIE);

  __enable_interrupt();   //<! Enable global interrupts
}


/*! \brief Initialize Timer Counter 0 in fast PWM mode
 *
 * \note Function only called once and can be inlined (forced)
 */
#pragma inline=forced
void Init_TC0( void )
{
  // Timer mode 3 (fast PWM)
  TCCR0A = (1<<WGM01)|(1<<WGM00);
  TCCR0B = (0<<WGM02) | (1<<CS00);
  // start counting from zero
  TCNT0 = 0;
  // T0 OVF ont enable
  TIMSK0 |= (1<<TOIE0);
}


/*! \brief Initialize ADC and perform dummy conversion.
 *
 * \note Function only called once and can be inlined (forced)
 */
#pragma inline=forced
void Init_ADC( void )
{
  // VCC voltager ref, ADC2 (PB4) as default input
  ADMUX = 2;
  // Enable ADC, ADC prescaler /64
  ADCSRA = (1<<ADEN) | (1<<ADPS2) | (1<<ADPS1);

  // Start conversion and wait for it to complete (result not used)
  ADCSRA |= (1<<ADSC);            // Start convertion
  while (ADCSRA & (1<<ADSC));     // Wait for conversion to complete
  ADCSRA = ADCSRA;                // Clear ADC interrupt flag

}


/*! \brief Starts the fan
 *
 * Set coilduty to start value, and starts fan
 */
void startFan(void)
{
  gFlags.starting = TRUE;
  coilDuty = STARTPWMDUTY;
  coilActivate();
}


/*! \brief Reads Hall sensor an activate the correct coil
 */
void coilActivate(void)
{
  if ((PINB & IO_HALL) == 0){
    // energize second coil: turn off OCR1A and turn on OCR1B (PB4)
    TCCR0A &= ~(1 << PWM1A);
    TCCR0A |= (1 << PWM1B);
  }
  else{
    // energize first coil: turn off OCR1B and turn on OCR1A (PB1)
    TCCR0A &= ~(1 << PWM1B);
    TCCR0A |= (1 << PWM1A);
  }
}


/*! \brief Reads ADC input
 */
int ADC_read(char input)
{
    // Hole ADC value
    int ADC;

    // VCC ref and ADCx
    ADMUX = (0<<REFS0) | (0x07&input);
    // Clear ADIF and start single conversion
    ADCSRA |= (1 << ADIF) | (1<<ADSC);
    // wait for conversion done, ADIF flag active
    while(!(ADCSRA & (1 << ADIF)));
    // read out ADCL register
    ADC = ADCL;
    // read out ADCH register
    ADC += (ADCH << 8);

    return ADC;
}
