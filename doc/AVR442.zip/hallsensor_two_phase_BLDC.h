// This file has been prepared for Doxygen automatic documentation generation
/*! \file *******************************************************************
 * Application:
 *  Control of two-phase Brushless DC motor with hall sensor.
 *  Implementation madefor a standard PC fan.
 *  
 * File: two_phase_sensorless_BLDC.h
 * 
 * $Revision: 1.1 $
 * Original Author: Robert Staven, Atmel Corp.
 * $Author: rstaven $, Atmel Corp.
 * $Date: Friday, June 24, 2005 06:17:54 UTC $
 *
 **************************************************************************/
#ifndef HALLSENSOR_TWO_PHASE_BLDC_H
#define HALLSENSOR_TWO_PHASE_BLDC_H

#define TRUE 1
#define FALSE 0

// Hall sensor input pin
#define IO_HALL   (1<<PB3)

// Used to turn on/off PWM
#define PWM1A COM0A1
#define PWM1B COM0B1

//! Delay before detcting stall (counting at 18750Hz)
#define STALL_LIM (unsigned int)18750*2 // 2 sec
//! Time before restarting fan (counting at 18750Hz) 
#define STALLTIMEOUT (unsigned long)18750*10 // 10 sec
//! Duty cycle to use when starting fan
#define STARTPWMDUTY 0xFF

#pragma vector = PCINT0_vect
__interrupt void pin_change(void);
#pragma vector = TIM0_OVF_vect
__interrupt void TIM0_OVF(void);
void init(void);
void Init_TC0(void);
void Init_ADC(void);
void startFan(void);
void coilActivate(void);
int ADC_read(char input);

#endif
